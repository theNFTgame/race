INSTRUCTIONS:

To use this version of Zwoptex simply open the Zwoptex.html file in your favourite browser. You must have Flash Player v 10.2 or higher installed.


LICENSE:

This version of Zwoptex is free to use for personal or commercial purposes but comes with no support or documentation of any support.

It is -very old- and we recommend you upgrade to the Desktop version to continue getting updates and support. You can get more info about Zwoptex at http://zwopple.com/zwoptex/
